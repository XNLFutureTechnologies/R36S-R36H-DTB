## 60hz DTB for Panel 4
> [!IMPORTANT]  
> Note: The 60Hz variant is experimental. We'd be happy to hear from any issues you encounter compared to the stock 77Hz mode.
